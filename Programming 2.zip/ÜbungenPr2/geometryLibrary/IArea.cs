﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using Point = vectorLibrary.Point;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace geometryLibrary
{
    public interface IArea
    {
        double Area { get; }
    }
}
